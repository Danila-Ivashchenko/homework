﻿#include <iostream>
#include <chrono>
#include "class_array.h"

using namespace std;

Array setArray(const int& n) {
    Array arr(n);
    for (int i = 0; i < n; i++)
        arr.insert(i + 1);
    return arr;
}

void iosif(const int& k,const int& n, Array& arr) {
    double start = clock();
    int pos = (k - 1) % n;
    while (arr.getSize() != 1) {
        //cout << arr[pos] << endl;
        arr.remove(pos);
        pos = (pos + k - 1) % arr.getSize();
    }
    double end = clock();
    cout << "n = " << n << ", time = " << (end - start) / 1000 << endl;
    cout << arr << endl;
}

void full_iosif(const int& k, int n) {
    Array arr = setArray(n);
    iosif(k, n, arr);
}

int main()
{
    int n = 1000, k = 2;
    for (int i = 0; i < 7; i++) {
        if (i > 0) {
            if (i % 2 == 0)
                n *= 2;
            else
                n *= 5;
        }
        full_iosif(k, n);
    }

    return 10;
}